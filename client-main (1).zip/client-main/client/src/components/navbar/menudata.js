export const menudata = [
    {
        title: "Search",
        url: "/search",
        cName: "nav-links",
        icon: "fa fa-search"
    },
    {
        title: "Booking",
        url: "/booking",
        cName: "nav-links",
        icon: "fa fa-calendar-check-o"
    },
    {
        title: "Schedule",
        url: "/schedule",
        cName: "nav-links",
        icon: "fa fa-calendar"
    },
    {
        title: "Lessons",
        url: "/lessons",
        cName: "nav-links",
        icon: "fa fa-user-plus"
    },
    {
        title: "Chat",
        url: "/chat",
        cName: "nav-links",
        icon: "fa fa-commenting"
    }
];
