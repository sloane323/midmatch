function Home() {
    return (
        <>
            <h1>
                <a style={{ color: "blue", lineHeight: 10, padding: 0 }}>
                    This is home
                </a>
            </h1>
        </>
    );
}

export default Home;
