function Search() {
    return (
        <>
            <h1>
                <a style={{ color: "blue", lineHeight: 10, padding: 40 }}>
                    This is Search
                </a>
            </h1>
        </>
    );
}

export default Search;
