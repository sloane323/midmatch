import React from "react";
import MyProList from "./MyProList";

const MyList_MyProList = () => {
  // Your component logic here
  return (
    <div>
      <div>
        <MyProList />
      </div>
    </div>
  );
};

export default MyList_MyProList;
